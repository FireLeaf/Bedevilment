#include "Artemis/Component.h"
#include "Artemis/World.h"

namespace artemis {
	
  Component::~Component() {
    
  }
	
};
